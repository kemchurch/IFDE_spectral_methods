% This script generates the spectrum of M_{N1,N2} for the "flower petals"
% DDE. Set the parameters c, tau and N2 as desired.

c = 10; % Real
tau = 3; % Positive integer
N2 = 200; % Positive integer

%%% --------------------------- %%%

A = cell(2,1);
B = cell(2,1);
A{1} = zeros(2,2);
A{2} = zeros(2,2);
B{1} = c*[0,-1;1,0];
B{2} = -B{1};
C1 = zeros(2,2);
C2 = zeros(2,2);

[M,~,~]=M_truncation(A,B,C1,C2,2,tau,N2);
plot(eig(M),'.k');