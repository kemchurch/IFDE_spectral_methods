% This script proves Theorem 9.1.3. It can be run without modifications.
% It will also plot all elments included in the left side of Figure 3, the
% entirety of which can be constructed using insets, rectangles and line
% elements for illustration.

tau = 1;
period = 1;
beta = 0.1;
rho = 1;
K = 1;
d1 = 0.02;
d2 = 0.03;
h = infsup(0.065,0.066);

N2 = 150;
nu = intval(1.17);
dim = 1;
p = period;
q = tau;

Zero = intval(zeros(dim,dim));

% -- Validation data
Morse_radius = intval(0.8);
lambda = intval(1);
sector_radius = intval(5*1E-3);
omega = intval(2.5*1E-3);


% -- Main body of script. -------------------------

disp('Starting proof of Theorem 9.1.3.')
disp('::::::');

val = struct('validate',1,'Morse_radius',Morse_radius,...
    'lambda',lambda,'sector_radius',sector_radius,'omega',omega,...
    'plot',1);

A = -intval(d2);
A_tail = 0;
B = intval(rho)*intval(beta)*intval(K)*exp(-intval(d1)*tau);
B_tail = 0;
C1 = -intval(h);
C2 = 0;

disp('Computing interval monodromy operator for wide parameter h=[0.065,0.066].')
disp('::::::');
[M,E,W]=M_truncation_int(A,B,C1,C2,p,q,N2);
disp('Computing c2, c3 bounds.')
if q>1
    [c2,c3]=bound_1pLq_c2c3(A,A_tail,B,B_tail,C1,C2,M,W,nu,N2,q,val);
else
    [c2,c3]=bound_pq1_c2c3(A,A_tail,B,B_tail,C1,M,W,nu,N2,val);
end
disp(['Bound c2 = ',num2str(sup(c2))]);
disp(['Bound c3 = ',num2str(sup(c3))]);
val.c2c3=sup(c2*c3);
disp('::::::');

% -- MORSE INDEX AT RADIUS 0.8 --
val.type = 'Morse';
disp('Computing mesh for c1 bound calculation: Morse index at radius 0.8.')
c1_intervals = 10;
finecomp = 800;
mesh_M = getmesh(c1_intervals,M,dim,nu,val,q,finecomp,'proxy');
val.mesh = mesh_M;
disp('Computing c1 bound for Morse index at radius 0.8.')
disp('::::::');
[c1_Morse,mesh_Morse,curve_Morse]=bound_pq1_c1(M,dim,nu,val);
disp(['Bound c1 (Morse index) = ',num2str(sup(c1_Morse))]);
disp(['Product c1*c2*c3 = ', num2str(sup(c1_Morse*c2*c3))]);
if sup(c1_Morse*c2*c3)<1
    disp('Success, eigenvalues with modulus >=0.8 are validated.')
    Morseflag = 1;
else
    disp('Proof failed.')
    Morseflag = 0;
    return
end
disp('::::::');

% -- RADIAL SECTOR --
val.type = 'sector';
disp('Computing mesh for c1 bound calculation: Radial sector.')
c1_intervals = 10;
finecomp = 5000;
mesh_RS = getmesh(c1_intervals,M,dim,nu,val,q,finecomp,'proxy');
val.mesh = mesh_RS;
disp('Computing c1 bound for radial sector.')
disp('::::::');
[c1_sector,mesh_sector,curve_sector]=bound_pq1_c1(M,dim,nu,val);
disp(['Bound c1 (radial sector) = ',num2str(sup(c1_sector))]);
disp(['Product c1*c2*c3 = ', num2str(sup(c1_sector*c2*c3))]);
if sup(c1_sector*c2*c3)<1
    disp('Success, eigenvalues in the radial sector are validated.')
    Sectorflag = 1;
else
    disp('Proof failed.')
    Sectorflag = 0;
    return
end
disp('::::::');

% -- GET DISCRETIZED INTERVAL MONODROMY OPERATORS FOR ENDPOINTS OF h,
% ENCLOSE THEIR EIGENVALUES, ENSURE THAT THESE ARE CONTAINED IN THE
% RADIAL SECTOR AND CHECK THE MORSE INDEX AT RADIUS 1.

val.plot = 0;
% -- h = 0.065
disp('Checking enclosure and location of modulus >=0.8 eigenvalues for h = 0.065.');
disp('::::::');
h = intval(0.065);
C1 = -intval(h);
[M0,E0,W0]=M_truncation_int(A,B,C1,C2,p,q,N2);
[Eigs0,pol0]=verify_the_eigs(M0,0,0);
iEigs0 = intval(Eigs0);
N_Eigs0 = inf(abs(iEigs0));
index0 = find(N_Eigs0>sup(Morse_radius));
if length(index0)==1
    disp('Found 1 eigenvalue with modulus >= 0.8. at parameter h = 0.065.');
    numflag = 1;
else
    disp('Found more than one eigenvalue with modulus >= 0.8. at parameter h = 0.065. This is unexpected. Failure.');
    numflag = 0;
    return
end
flag0 = include_ball(iEigs0(index0),intval(pol0(index0)),...
    lambda,sector_radius,omega);
abs_index0_eig = abs(iEigs0(index0) + intval(pol0(index0)));
if flag0 == 1
    disp('Success, rigorous enclosure of the eigenvalue is contained in the radial sector.');
else
    disp('Failure of eigenvalue enclosure within radial sector.');
    return
end
if abs_index0_eig>1
    disp(['Success, the (approximate) eigenvalue ',num2str(mid(abs_index0_eig)), ' satisfies |lambda(0.065)|>1.'])
    flag0_eig=1;
    plot(real(mid(abs_index0_eig)), imag(mid(abs_index0_eig)), '.r');
else
    disp('The eigenvalue satisfies |lambda(0.065)|<=1. Failure.')
    flag0_eig=0;
    return
end
disp('Validating Morse index at radius 1 for h=0.065');
c1_intervals = 20;
finecomp = 8000;
val.type = 'Morse';
val.Morse_radius = intval(1);
mesh_R065 = getmesh(c1_intervals,M0,dim,nu,val,q,finecomp,'proxy');
val.mesh = mesh_R065;
[c1_065_Morse,~,~]=bound_pq1_c1(M0,dim,nu,val);
disp(['Bound c1 = ',num2str(sup(c1_065_Morse))]);
disp(['Product c1*c2*c3 = ', num2str(sup(c1_065_Morse*c2*c3))]);
if sup(c1_065_Morse*c2*c3)<1
    disp('Success, eigenvalues with modulus >=1 are validated.')
    Morseflag_065 = 1;
else
    disp('Proof failed.')
    Morseflag_065 = 0;
    return
end
disp('::::::');

% -- h = 0.066
disp('Checking enclosure and location of modulus >=0.8 eigenvalues for h = 0.066.');
disp('::::::');
h = intval(0.066);
C1 = -intval(h);
[M1,E1,W1]=M_truncation_int(A,B,C1,C2,p,q,N2);
[Eigs1,pol1]=verify_the_eigs(M1,0,0);
iEigs1 = intval(Eigs1);
N_Eigs1 = inf(abs(iEigs1));
index1 = find(N_Eigs1>sup(Morse_radius));
if length(index1)==1
    disp('Found 1 eigenvalue with modulus >= 0.8. at parameter h = 0.066.');
else
    disp('Found more than one eigenvalue with modulus >= 0.8. at parameter h = 0.066. This is unexpected. Failure.');
    return
end
flag1 = include_ball(iEigs1(index1),intval(pol1(index0)),...
    lambda,sector_radius,omega);
abs_index1_eig = abs(iEigs1(index1) + intval(pol1(index1)));
if flag1 == 1
    disp('Success, rigorous enclosure of the eigenvalue is contained in the radial sector.');
else
    disp('Failure of eigenvalue enclosure within radial sector.');
    return
end
if abs_index1_eig<1
    disp(['Success, the eigenvalue ',num2str(mid(abs_index1_eig)), ' satisfies |lambda(0.066)|<1.'])
    plot(real(mid(abs_index1_eig)), imag(mid(abs_index1_eig)), '.r');
    flag1_eig=1;
else
    disp('The eigenvalue satisfies |lambda(0.066)|<=1. Failure.')
    flag1_eig=0;
    return
end
disp('Validating Morse index at radius 1 for h=0.066');
c1_intervals = 16;
finecomp = 18000;
val.type = 'Morse';
val.Morse_radius = intval(1);
mesh_R066 = getmesh(c1_intervals,M1,dim,nu,val,q,finecomp,'proxy');
val.mesh = mesh_R066;
[c1_066_Morse,~,~]=bound_pq1_c1(M0,dim,nu,val);
disp(['Bound c1 = ',num2str(sup(c1_066_Morse))]);
disp(['Product c1*c2*c3 = ', num2str(sup(c1_066_Morse*c2*c3))]);
if sup(c1_066_Morse*c2*c3)<1
    disp('Success, eigenvalues with modulus >=1 are validated.')
    Morseflag_066 = 1;
else
    disp('Proof failed.')
    Morseflag_066 = 0;
    return
end
disp('::::::');

if min([Morseflag,Sectorflag,numflag,flag0,flag0_eig,flag1,flag1_eig,Morseflag_065,Morseflag_066])==1
    disp('Proof completed. Success.')
    plot(exp(1i*linspace(0,2*pi,200)),'--b')
    axis([-1.01 1.01 -1 1]);
else
    disp('Proof failed.')
end
