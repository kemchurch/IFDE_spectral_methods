% This script runs the timed test performed in Section 9.2 for the data
% supplied in highdimension_float_timetest_matrices_const.mat file. 
% There are no provisions for running out of memory; if you have 
% insufficient memory to complete the test the script will fail.
load('highdimension_float_timetest_matrices_const.mat');
M = cell(2,3,3,3);
time = cell(2,3,3,3);

for d = 1:3
    if d==1
        D = data_10d;
        dim = 10;
    elseif d==2
        D = data_50d;
        dim = 50;
    elseif d==3
        D = data_100d;
        dim = 100;
    end
    for N=1:3
        if N==1
            N2 = 10;
        elseif N==2
            N2 = 50;
        elseif N==3
            N2 = 100;
        end
        for p=2:2
            for q=1:3
                tic_run = tic;
                Mono=M_truncation(D.A{p,q},D.B{p,q},...
                    D.C1{p,q},D.C2{p,q},p,q,N2);
                disp(['The time for discretization for dimension ',num2str(dim),' example with p=',num2str(p),', q=',num2str(q),', and N2=',num2str(N2),' is: ']);
                tic_run = toc(tic_run)
                time{p,q,d,N} = tic_run;
                M{p,q,d,N}=abs(eigs(Mono,1, 'lm'));
                clear Mono
            end
        end
    end
end