% This script generates a random sample problem as outlined in 
% Section 9.1. Set the dimension (dim) period (p),  delay (q) and number of
% nonconstant modes (N1) as desired.
%p = 1;
%q = 1;
dim = 200;
N1 = 0;
%%% ----------------- %%%

N1 = 1+N1;

%%% Build C2
Z = 0.1*randn(dim^2,1);
Z(Z>0.1)=[];
Z(Z<-0.1)=[];
while length(Z)<dim^2
    Zn = 0.1*randn;
    if abs(Zn)<0.1
        Z = [Z;Zn];
    end
end
C2 = reshape(Z,[dim,dim]);

%%% Build C1
D = 2*rand(dim,dim) - 1;
k = rand(1);
C1 = (k/norm(D))*D-eye(dim);

%%% Build A and B
A=cell(p,1);
B=cell(p,1);
for k=1:p
    ak = rand(1);
    bk = rand(1);
    A{k} = ak*(2*rand(dim*N1,dim) - 1);
    B{k} = bk*(2*rand(dim*N1,dim) - 1);
    for j=1:N1
        A{k}(1+dim*(j-1):dim*j, : ) = 2^(-(j-1))*A{k}(1+dim*(j-1):dim*j, : );
        B{k}(1+dim*(j-1):dim*j, : ) = 2^(-(j-1))*B{k}(1+dim*(j-1):dim*j, : );
    end
end