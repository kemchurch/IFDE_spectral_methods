% This script proves Theorem 9.1.1. Choose the value of tau and h that you
% want to prove, and adjust N2 accordingly.

% -- CHOOSE THE VALUE PARA, WHICH SETS TAU, h AND THE OTHER PARAMETERS
% FOR THE PROOF.
% PARA = 1; tau=1, h=0.075
% PARA = 2; tau=1, h=0.060
% PARA = 3; tau=2, h=0.075
% PARA = 4; tau=2, h=0.060
% PARA = 5; tau=3, h=0.075
% PARA = 6; tau=3, h=0.060
% -------------------------------------------------------------------
period = 1;
beta = 0.1;
rho = 1;
K = 1;
d1 = 0.02;
d2 = 0.03;

if PARA==1
    tau=1;
    h=0.075;
    N2=30;
    nu=1.17;
    finecomp=800;
    c1_intervals=7;
elseif PARA==2
    tau=1;
    h=0.060;
    N2=30;
    nu=1.17;
    finecomp=1000;
    c1_intervals=12;
elseif PARA==3
    tau=2;
    h=0.075;
    N2=30;
    nu=1.17;
    finecomp=800;
    c1_intervals=12;
elseif PARA==4
    tau=2;
    h=0.060;
    N2=40;
    nu=1.17;
    finecomp=2000;
    c1_intervals=12;
elseif PARA==5
    tau=3;
    h=0.075;
    N2=40;
    nu=1.17;
    finecomp=1000;
    c1_intervals=14;
elseif PARA==6
    tau=3;
    h=0.060;
    N2=70;
    nu=1.3;
    finecomp=4000;
    c1_intervals=22;
end

Morse_radius = intval(1);
dim = 1;
p = period;
q = tau;

Zero = intval(zeros(dim,dim));

% -- Main body of script. -------------------------

val = struct('validate',1,'type','Morse','Morse_radius',Morse_radius,...
    'plot',1);

A = -intval(d2);
A_tail = 0;
B = intval(rho)*intval(beta)*intval(K)*exp(-intval(d1)*tau);
B_tail = 0;
C1 = -intval(h);
C2 = 0;

% --- Compute interval monodromy matrix, N2 (nonconstant) modes and compute
% the c2, c3 bounds.

disp('Computing interval monodromy operator.')
[M,E,W]=M_truncation_int(A,B,C1,C2,p,q,N2);
disp('Computing c2, c3 bounds.')
if q>1
    [c2,c3]=bound_1pLq_c2c3(A,A_tail,B,B_tail,C1,C2,M,W,nu,N2,q,val);
else
    [c2,c3]=bound_pq1_c2c3(A,A_tail,B,B_tail,C1,M,W,nu,N2,val);
end
disp(['Bound c2 = ',num2str(sup(c2))]);
disp(['Bound c3 = ',num2str(sup(c3))]);

% --- Compute the c1 bound. ---
val.c2c3=sup(c2*c3);
disp('Computing mesh for c1 bound calculation.')
mesh = getmesh(c1_intervals,M,dim,nu,val,q,finecomp,'proxy');
val.mesh = mesh;
disp('Computing c1 bound.')
if q>1
    [c1,mesh,curve]=bound_1pLq_c1(M,dim,nu,val,q);
else
    [c1,mesh,curve]=bound_pq1_c1(M,dim,nu,val);
end
disp(['Bound c1 = ',num2str(sup(c1))]);

% --- Output result and validate the eigenvalues. ---
disp(['Product c1*c2*c3 = ', num2str(sup(c1*c2*c3))]);
if sup(c1*c2*c3)<1
    disp('Success, eigenvalues with modulus >=1 validated.')
    disp('Moving on to validated eigenvalue calculation.')
    [Eigs,rad_pol] = verify_the_eigs(M,0,0);
    index = count_index(Eigs,rad_pol,sup(val.Morse_radius));
    disp(['Generalized Morse index = ',num2str(index)])
    plot(real(Eigs),imag(Eigs),'*','color',[0 0 0])
    color = [0.7 0 0];
    set(gca,'FontSize',20)
    xlabel('$$Re(\lambda)$$','interpreter','latex','FontSize',25)
    ylabel('$$Im(\lambda)$$','interpreter','latex','FontSize',25)
    axis equal
    if index>0
        disp('The equilibrium is unstable.')
    else
        disp('The equilibrium is stable.')
    end
else
    disp('Proof failed.')
end