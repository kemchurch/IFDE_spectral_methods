% This script proves Theorem 9.1.2. It can be run without modifications.

tau = 1;
period = 1;
beta = 0.1;
rho = 1;
K = 1;
d1 = 0.02;
d2 = 0.03;

N2=35;
nu = intval(1.17);
Morse_radius = intval(1);
dim = 1;
p = period;
q = tau;

Zero = intval(zeros(dim,dim));

% -- Main body of scrupt. Essentially do the predator_prey script with two
% intervals of h. The main difference is we don't need to validate
% eigenvalue location relative to the unit circle.

h0 = infsup(0,0.05);
h1 = infsup(0.05,0.06);
flag = 1;

val = struct('validate',1,'type','Morse','Morse_radius',Morse_radius,...
    'plot',1);

disp('Starting proof of Theorem 9.1.2.')

for k=0:1
    if k==0
        h = h0;
    else
        h = h1;
    end
    A = -intval(d2);
    A_tail = 0;
    B = intval(rho)*intval(beta)*intval(K)*exp(-intval(d1)*tau);
    B_tail = 0;
    C1 = -intval(h);
    C2 = 0;

    % --- Compute interval monodromy matrix, N2 (nonconstant) modes and compute
    % the c2, c3 bounds.
    disp(['Starting proof for interval h = [',num2str(inf(h)),',',num2str(sup(h)),'].']);
    disp('Computing interval monodromy operator.')
    [M,E,W]=M_truncation_int(A,B,C1,C2,p,q,N2);
    disp('Computing c2, c3 bounds.')
    if q>1
        [c2,c3]=bound_1pLq_c2c3(A,A_tail,B,B_tail,C1,C2,M,W,nu,N2,q,val);
    else
        [c2,c3]=bound_pq1_c2c3(A,A_tail,B,B_tail,C1,M,W,nu,N2,val);
    end
    disp(['Bound c2 = ',num2str(sup(c2))]);
    disp(['Bound c3 = ',num2str(sup(c3))]);
    val.c2c3=sup(c2*c3);

    % --- Compute the c1 bound. ---
    if k==0
        finecomp = 800;
        c1_intervals = 20;
    else
        finecomp = 2000;
        c1_intervals = 20;
    end
    disp('Computing mesh for c1 bound calculation.')
    mesh = getmesh(c1_intervals,M,dim,nu,val,q,finecomp,'explicit');
    val.mesh = mesh;
    disp('Computing c1 bound.')
    if q>1
        [c1,mesh,curve]=bound_1pLq_c1(M,dim,nu,val,q);
    else
        [c1,mesh,curve]=bound_pq1_c1(M,dim,nu,val);
    end
    disp(['Bound c1 = ',num2str(sup(c1))]);
    clf

    % --- Output result ---
    disp(['Product c1*c2*c3 = ', num2str(sup(c1*c2*c3))]);
    if sup(c1*c2*c3)<1
        disp('Success.')
    else
        disp('Proof failed.')
        flag=0;
    end
    close gcf
end
if flag==1
    disp('Proof complete. The Morse index is constant on the interval h=[0,0.06].')
else
    disp('The proof failed for one or both of the intervals h_0, h_1.')
end