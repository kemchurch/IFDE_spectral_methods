function c1_contribution = skew_hopf_part2(instance)
% This is one of two parts needed for the proof of Theorem 8.2.1. This is
% the second part. The input parameter 'instance' is a natural number from
% 1 to 10. This function computes the contribution to the c1 bound
% attributed to one tenth of the discretized mesh. Taking the maximum of
% all of them (1 to 10) yields a valid c1 bound for the proof.
n = instance-1;
load('skew_hopf_part1_data.mat','M','dim','nu','val');
val.mesh = n/10:1E-3:(n+1)/10;
[c1_contribution,~,~]=bound_pq1_c1(M,dim,nu,val);
end