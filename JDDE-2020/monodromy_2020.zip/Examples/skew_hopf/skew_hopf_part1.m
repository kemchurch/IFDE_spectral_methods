% This is one of two parts needed for the proof of Theorem 8.2.1. This one
% computes the discretized monodromy operator and c2/c3 bounds. It also
% verifies the approximate eigenvalue lambda* from the proof of the theorem
% and checks that the enclosure of this eigenvalue is contained in the
% radial sector. It then checks that this radial sector is strictly
% outside the unit disc. Finally, it saves the results necessary 
% for the next part of the proof in the form of a .mat file.  This .mat 
% file should be copied onto any extra computers you want to run the proof
% on if running in parallel.

tau = 1;
nu = intval(1.04);
N = 65;
Ni = intval(N);
beta = intval(3/2);
sector_radius = 0.055;          % Note: sector_radius, omega and lambda are 
omega = 0.1;                    % converted to intvals by other functions.
lambda = 0.405828912008976 + 0.974191597102970i;
dim = 2;
p = 1;
q = tau;
B_coeff = (-1)^(tau+1);
Zero = intval(zeros(dim,dim));

NN = 1000;

% --- Get validated interval Chebyshev coefficients for cos(pi(s-1)) and 
% sin(pi(s-1)), N (nonconstant) mode approximation --- 

disp('Building cos(pi(s-1)), sin(pi(s-1)) and their error estimates.')
val0 = struct('validate',1);
A0 = [0,intval(-2*pi);intval(2*pi),0];
B0 = Zero;
C10 = Zero;
C20 = Zero;
[M0,E0,W0] = M_truncation_int(A0,B0,C10,C20,1,1,N);
[c2_CS,c3_CS,rho] = bound_pq1_c2c3(A0,0,B0,0,C10,M0,W0,nu,N,val0);
CS = M0(3:end,1);
COS = intval(zeros(N+1,1));
SIN = intval(zeros(N+1,1));
for k=1:N+1
    COS(k)=CS(1+2*(k-1));
    SIN(k)=CS(2+2*(k-1));
end
CS_error = sup(c2_CS*c3_CS);
CS_nupow = nu.^(-(0:N)).';
% Rigorously enclose coefficients of cos, sin using the error bound.
COS = COS + infsup(-CS_error,CS_error)*CS_nupow; 
SIN = SIN + infsup(-CS_error,CS_error)*CS_nupow;

% -- Generate validation structure

val = struct('validate',1,'sector_radius',sector_radius,'omega',omega,...
    'lambda',lambda,'plot',0,'type','sector');

% --- Build the matrices A and B for the periodic orbit eigenvalue
% validation and the associated tails.
A = intval(zeros(dim*(N+1),dim));
A_tail = beta*CS_error;
B = intval(zeros(dim*(N+1),dim));
B_tail = beta*CS_error;
A(1:2,1:2) = [0,-intval(pi)-beta*SIN(1);intval(pi)-beta*SIN(1),0];
B(1:2,1:2) = B_coeff*[beta*(1+COS(1)),0;0,beta*(1-COS(1))];
for k=2:N+1
    A(1+(k-1)*2:k*2, :) = [0,-beta*SIN(k);-beta*SIN(k),0];
    B(1+(k-1)*2:k*2, :) = B_coeff*[beta*COS(k),0;0,-beta*COS(k)];
end

% --- Compute interval monodromy matrix, NN (nonconstant) modes and compute
% the c2, c3 bounds.
disp('Computing discretized interval monodromy operator.');
[M,~,W]=M_truncation_int(A,B,Zero,Zero,p,q,NN);
disp('Computing associated c2 and c3 bounds.');
[c2,c3]=bound_pq1_c2c3(A,A_tail,B,B_tail,Zero,M,W,nu,NN,val);
disp(['c2 = ',num2str(sup(c2))]);
disp(['c3 = ',num2str(sup(c3))]);
val.c2c3 = sup(c2*c3);

% --- Check the approximate eigenvalue
[eig,rad]=verify_the_eigs(M,length(M)-2,1.05);
idx = find(imag(eig)>0);
eig=eig(idx);
rad=rad(idx);
incflag = include_ball(eig,rad,lambda,sector_radius,omega);
if incflag == 1
    disp('Success, enclosure of the approximate eigenvalue obtained by radii polynomial is contained in the radial sector.');
else
    disp('Proof failed, enclosure of approximate eigenvalue is not contained in the radial sector.');
end

% --- Check that the radial sector is excluded from the unit disc.
if inf(abs(intval(lambda)) - intval(sector_radius))>1
    disp('Success, the radial sector is exluded from the unit disc.');
    disp(['Distance to the unit disc is bounded below by: ',num2str(inf(abs(intval(lambda)) - intval(sector_radius) - intval(1)))]);
else
    disp('Failure, the radial sector is intersects the unit disc.');
end

% --- Save everything needed for part 2.
save('skew_hopf_part1_data.mat','M','dim','nu','val');
disp('Part 1 of the proof is complete. Now run part 2 with input parameters instance=1,...,10. Take a maximum to generate the c1 bound.')