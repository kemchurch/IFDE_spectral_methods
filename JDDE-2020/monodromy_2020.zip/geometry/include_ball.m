function flag = include_ball(x,rad,lambda2,r2,omega2)
% Check whether B_rad(x) is contained in R_lambda2(r2,omega2). flag=1 if
% contained, 0 if not. Inputs are inflated to intervals if not already
% input as such.
lambda1 = intval(x);
r1 = intval(rad);
lambda2 = intval(lambda2);
r2 = intval(r2);
omega2 = intval(omega2);
omega1 = 2*asin(rad/(2*abs(x)));
arg_lambda1 = -1i*log(lambda1/abs(lambda1));
arg_lambda2 = -1i*log(lambda2/abs(lambda2));
flag = 1;
if abs(lambda2)-r2 > abs(lambda1)-r1
    flag = 0;
elseif abs(lambda1)+r1 > abs(lambda2)+r2
    flag = 0;
elseif arg_lambda2 - omega2 > arg_lambda1 - omega1
    flag = 0;
elseif arg_lambda1 + omega1 > arg_lambda2 + omega2
    flag = 0;
end
end