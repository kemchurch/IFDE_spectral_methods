function s = sector(t,lambda,r,omega,type)
% Radial sector parameterization function. Primarily used for plotting.
arg = -1i*log(lambda/abs(lambda));
if strcmp(type,'zero_four')==1
    if (0<=t) && (t<1)
        s = (abs(lambda)-r)*exp(1i*(arg+omega*(1-2*t)));
    elseif (1<=t) && (t<2)
        s = (abs(lambda)+(2*t-3)*r)*exp(1i*(arg-omega));
    elseif (2<=t) && (t<3)
        s = (abs(lambda)+r)*exp(1i*(arg+(2*t-5)*omega));
    elseif (3<=t) && (t<=4)
        s = (abs(lambda)+(7-2*t)*r)*exp(1i*(arg + omega));
    end
elseif strcmp(type,'zero_one')==1
    s = [(abs(lambda)-r)*exp(1i*(arg+omega*(1-2*t))) ;
       (abs(lambda)+(2*(t+1)-3)*r)*exp(1i*(arg-omega)) ;
       (abs(lambda)+r)*exp(1i*(arg+(2*(t+2)-5)*omega)) ;
       (abs(lambda)+(7-2*(t+3))*r)*exp(1i*(arg + omega))];
end
    
end