function fval = blocknorm(X,d,matnorm,val)
% fval = blocknorm(X,d,matnorm): compute blockwise norm of a d*Nxd matrix
% X, with dxd blocks, in the matnorm matrix norm.
N = size(X)*[1;0]/d;
fval = zeros(N,1);
if val == 1
    fval = intval(fval);
end
for k=1:N
   fval(k) = norm(X(1+(k-1)*d:k*d,:),matnorm); 
end

end