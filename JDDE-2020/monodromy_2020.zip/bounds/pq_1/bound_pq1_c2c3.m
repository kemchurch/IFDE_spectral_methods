function [c2,c3,rho] = bound_pq1_c2c3(A,A_tail,B,B_tail,C1,M,W,nu,N2,val)

d = size(A)*[0;1];
N1 = size(A)*[1;0]/d - 1;
%A = [A;zeros(d*(2*(N2+1)-N1),d)];
N2_integer = N2;
Id = eye(d,d);

if val.validate == 1 
    A = intval(A);
    B = intval(B);
    C1 = intval(C1);
    nu = intval(nu);
    N2 = intval(N2);
    Id = intval(Id);
end
if val.validate == 0
    A = mid(A);
    B = mid(B);
    C1 = mid(C1);
    W = mid(W);
end

Id_plus_C1_A = elementwise_product(Id+C1,A,d,val.validate);
Id_plus_C1_A_norm_nu = compute_chebnorm(nu,Id_plus_C1_A,d,inf,'ell_nu_1',val.validate);
Id_plus_C1_B = elementwise_product(Id+C1,B,d,val.validate);
Id_plus_C1_B_norm_nu = compute_chebnorm(nu,Id_plus_C1_B,d,inf,'ell_nu_1',val.validate);
A_norm_nu = compute_chebnorm(nu,A,d,inf,'ell_nu_1',val.validate);
A_norm_omega = compute_chebnorm(nu,A,d,inf,'omega',val.validate);
B_norm_nu = compute_chebnorm(nu,B,d,inf,'ell_nu_1',val.validate);
B_norm_omega = compute_chebnorm(nu,B,d,inf,'omega',val.validate);
%B_norm_omega = compute_chebnorm(nu,B,d,inf,'omega',val.validate);
g = g_func(nu);
nIC = norm(Id+C1,inf);

%Initialize DT, H_1^0, S
[DT,~]=DT_H10_mat(d,N2_integer,val.validate);
[DT_big,~]=DT_H10_mat(d,N2_integer+N1+1,val.validate);
SA = symmetrize(A,val.validate);
SB = symmetrize(B,val.validate);

%------COMPUTATION OF c2------%

%Computing matrices needed for K0, K0dot, K1 and J0.
Q = eye(d*(N2_integer+1),d*(N2_integer+1)) - W(d+1:end,d+1:end);
Qinv = inv(Q);
Id_plus_C1_Qinv = elementwise_product(Id+C1,Qinv,d,val.validate);
GJ0A = boldG_func(d,DT_big,N1,N2_integer,A,eye(d*(N2_integer+1)),val.validate);

%Computing K0, K0dot, K1

K0 = compute_opnorm_ell_nu_1(Qinv,d,nu,inf,val.validate);
K0dot = compute_opnorm_ell_nu_1(Id_plus_C1_Qinv,d,nu,inf,val.validate);
K1 = compute_row12_13(Qinv,DT,SA,A_norm_omega,d,nu,inf,val.validate);

%Compute J0(A)
J0A = compute_opnorm_ell_nu_1(GJ0A,d,nu,inf,val.validate);

%Compute K2
K2 = compute_K2(Id_plus_C1_Qinv,DT,A_norm_omega,SA,d,nu,inf,val.validate);

%Compute alphaA
alphaA = (1/(4*(N2+1)))*( (nu+2/nu+1/nu^3)*A_norm_nu - (1/nu + 1/nu^3)*norm(A(1:d,1:d),inf) );
beta = max(J0A, K1+alphaA);

%Compute rhos
rho1 = (K0*(1+nu/2)+(nu+1/nu)/(2*(N2+1)))*A_tail + beta;
rho_at_zero = g*K0dot*(1+nu/2)*A_tail + max(2*g*nIC*A_tail , 2*Id_plus_C1_A_norm_nu/nu^(N2+1) + K2);

%Computng norm of I-W_N1N2 in X_nu^N2
norm_ImW = norm_nu_gen_op(nu,inv(eye(d*(N2_integer+2),d*(N2_integer+2)) - W),1,d,inf,'op_headbody',val.validate);

%Compute rho and c2
rho = max(rho1,rho_at_zero);
c2=max(1,norm_ImW)/(1-rho);

%------COMPUTATION OF c3------%

%Define the matrix M_bold and compute its norm
M_bold = M(1+d:end,1+d:end);
M_bold_norm_nu = compute_opnorm_ell_nu_1(M_bold,d,nu,inf,val.validate);

%Compute matrices needed for J0(B), L0, L1
GJ0B = boldG_func(d,DT_big,N1,N2_integer,B,eye(d*(N2_integer+1)),val.validate);
G_A_Mbold = boldG_func(d,DT_big,N1,N2_integer,A,M_bold,val.validate);
G_A_Qinv_Idbox = boldG_func(d,DT_big,N1,N2_integer,A,Qinv*(blkdiag(eye(d),zeros(d*N2_integer,d*N2_integer))),val.validate);

%Compute K_0^0
K0_upper0 = sum(blocknorm(Qinv(:,1:d),d,inf,val.validate));

%Compute L0, L1, L2 and J0(B)B
J0B = compute_opnorm_ell_nu_1(GJ0B,d,nu,inf,val.validate);
L0 = compute_opnorm_ell_nu_1(G_A_Qinv_Idbox,d,nu,inf,val.validate);
L1 = compute_opnorm_ell_nu_1(G_A_Mbold,d,nu,inf,val.validate);
L2 = compute_row12_13(eye(d*(N2_integer+1)),DT,SB,B_norm_omega,d,nu,inf,val.validate);

%Compute alphaB
alphaB = (1/(4*(N2+1)))*( (nu+2/nu+1/nu^3)*B_norm_nu - (1/nu + 1/nu^3)*norm(B(1:d,1:d),inf) );

%Compute gamma
gamma = max((1+nu/2)*M_bold_norm_nu*A_tail+L1+J0B, L2+alphaB);

%Compute kappas
kappa1 = (1+nu/2)*(K0_upper0*A_tail + B_tail) + L0 + gamma;
kappa_at_zero = 2*g*nIC*K0_upper0*A_tail + max(2*g*nIC*B_tail , 2*g*nIC*A_tail*M_bold_norm_nu + ( (1+1/nu^(N2+1))*nIC*B_tail + 2*Id_plus_C1_B_norm_nu)/nu^(N2+1) );

%Compute c3
c3=max(kappa1,kappa_at_zero);

end