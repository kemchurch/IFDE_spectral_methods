function prod = elementwise_product(A,B,dim,val)
prod = zeros(size(B));
if val == 1
    prod = intval(prod);
end
a = rows(B)/dim;
for j=0:a-1
    prod(1+j*dim:(j+1)*dim,:) = A*B(1+j*dim:(j+1)*dim,:);
end
end