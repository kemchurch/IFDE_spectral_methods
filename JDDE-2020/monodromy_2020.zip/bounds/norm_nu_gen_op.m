function fval = norm_nu_gen_op(nu,input,delay,dimension,matnorm,type,val)
% fval = norm_nu_gen_op(nu,input,delay,dimension,matnorm,type,val:
% Full implementation of the bound of Lemma 5.1.1 for finite matrix
% operator. type=='op_body' is suitable for an operator on a product space
% (ell_nu^1)^p for some p, and type=='op_headbody' is suitable for an
% operator on the entirety of X_nu.
d = dimension;
q = delay;
X = input;
if val == 1
    nu = intval(nu);
end

if strcmp(type,'op_body')==1
    N = size(X)*[1;0]/(d*q);
    if val == 1
        V = intval(zeros(q,q));
        V_sumrow = intval(zeros(q));
    else
        V = zeros(q,q);
        V_sumrow = zeros(q);
    end
    for k=1:q
        for m=1:q
            V_mk = X(1+d*N*(k-1):d*N*k, 1+d*N*(m-1):d*N*m);
            V(m,k) = compute_norm_op_ell_nu_1(V_mk,d,nu,matnorm);
        end
        V_sumrow(k) = sum(V(:,k));
    end
    fval = max(V_sumrow);
elseif strcmp(type,'op_headbody')==1
    N = (size(X)*[1;0]-d)/(d*q);
    X_T0 = X(1:d,1:d);
    X_T = X(1:d,d+1:end);
    X_U = X(d+1:end,1:d);
    X_V = X(d+1:end , d+1:end);
    if val == 1
        T = intval(zeros(q,1));
        U = intval(zeros(q,1));
        V = intval(zeros(q,q));
        V_sumrow = intval(zeros(q,1));
        U_plus_V = intval(zeros(q,1));
    else
        T = zeros(q,1);
        U = zeros(q,1);
        V = zeros(q,q);
        V_sumrow = zeros(q,1);
        U_plus_V = zeros(q,1);
    end
    for k=1:q 
        T(k) = compute_chebnorm(nu,X_T(1:d,1+d*N*(k-1): d*N*k)',d,matnorm,'T_script',val);
        U(k) = compute_chebnorm(nu,X_U(1+d*N*(k-1):d*N*k, 1:d),d,matnorm,'ell_nu_1',val);
        for m=1:q
            V_mk = X_V(1+d*N*(k-1):d*N*k, 1+d*N*(m-1):d*N*m);
            V(m,k) = compute_opnorm_ell_nu_1(V_mk,d,nu,matnorm,val);
        end
        V_sumrow(k) = sum(V(:,k));
        U_plus_V(k) = U(k) + V_sumrow(k);
    end    
    T_bold = norm(X_T0,matnorm) + sum(T);
    fval = max(T_bold, max(U_plus_V));
end

end