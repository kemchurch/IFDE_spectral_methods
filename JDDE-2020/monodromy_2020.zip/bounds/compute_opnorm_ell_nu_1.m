function opnorm = compute_opnorm_ell_nu_1(X,d,nu,matnorm,val)
% opnorm = compute_opnorm_nu_1(X,d,nu,matnorm): computers a bound for the 
% norm (opnorm) of the linear map represented as a (d*(NN+1))x(d*(N+1)) 
% matrix acting on truncated ell_nu^1 sequences of C^d vectors,
% relative to the prescribed (matnorm) norm. Implementation from 
% Lemma 5.1.1. The lowfloor parameter cuts off the summation at a specified
% lower index.
N = size(X)*[0;1]/d - 1;
NN = size(X)*[1;0]/d - 1;
nupow = (nu.^(0:NN)).';
vect = zeros(1,N+1);
if val == 1
    vect = intval(vect);
end
for k=0:N
    Vk = blocknorm(X(:,1+k*d:(k+1)*d), d, matnorm,val).*nupow;
    vect(k+1) = sum(Vk)/nupow(k+1);
end
opnorm = max(vect);
end