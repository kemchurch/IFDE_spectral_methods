function R = compute_row12_13(X,DT,S,U_omega,d,nu,matnorm,val)
N2 = size(X)*[1;0]/d - 1;
N1 = (size(S)*[1;0]/d-1)/2;
nupow_internal = (nu.^(0:N2)).';
nupow_external = nu.^(N2+1:N2+1+N1);
R_vect = zeros(1,N1+1);
if val == 1
    R_vect = intval(R_vect);
    weight = U_omega/((intval(N2)-intval(N1)+1)^2-1);
else
    weight = U_omega/((N2-N1+1)^2-1);
end
X_times_DT = X*DT;
for k=0:N1
    %rowk = X_times_DT(1+k*d:(k+1)*d, :);
    vect = (weight*blocknorm(X(:,1:d),d, matnorm,val) +  blocknorm(X_times_DT(1+k*d:(k+1)*d, :)*Zmatrix(k,d,N1,N2)*S, d, matnorm,val)).*nupow_internal;
    R_vect(k+1) = sum(vect)/nupow_external(k+1);
end
R = max(R_vect);
end