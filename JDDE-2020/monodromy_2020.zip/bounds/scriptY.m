function fval = scriptY(Y,N1,N2,nu,val)
s1 = 0;
s2 = 0;
d = columns(Y);
Y0 = norm(Y(1:d,:));
if val == 1
    Y=[Y;intval(zeros(d*(2*(N2+1)-N1),d))];
else
    Y=[Y;zeros(d*(2*(N2+1)-N1),d)];
end
for j=1:N1
    s1j = 0;
    if N2+2-j <= N2
        if val == 1
            vec = 1./intval(N2+2-j:1:N2);
        else
            vec = 1./(N2+2-j:1:N2);
        end
        s1j = s1j + nu*sum(vec);
    end
    if N2-j <= N2
        if val == 1
            vec = 1./intval(N2-j:1:N2);
        else
            vec = 1./(N2-j:1:N2);
        end
        s1j = s1j + (1/nu)*sum(vec);
    end
    if val == 1 
        s1 = s1 + (1/(4*nu^j))*norm(Y(1+(j-1)*d:j*d,:))*s1j...
            + (1/nu^(N2+1))*(Y0/intval(N2+1))*(1+1/2*intval(N2));
        s2 = s2 + norm(Y(1+(j-1)*d:j*d,:))*( (1/intval(N2+1-j))*(2-1/intval(2*(N2-j))) + (1/intval(N2+1+j))*(2-1/intval(2*(N2+j))) );
    else
         s1 = s1 + (1/(4*nu^j))*norm(Y(1+(j-1)*d:j*d,:))*s1j...
            + (1/nu^(N2+1))*(Y0/(N2+1))*(1+1/2*(N2));
        s2 = s2 + norm(Y(1+(j-1)*d:j*d,:))*( (1/(N2+1-j))*(2-1/(2*(N2-j))) + (1/(N2+1+j))*(2-1/(2*(N2+j))) );
    end
end
if val == 1
    fval = Y0/(4*nu*N2) + s1 + (1/intval(nu)^(N2+1))*s2;
else
    fval = Y0/(4*nu*N2) + s1 + (1/(nu)^(N2+1))*s2;
end