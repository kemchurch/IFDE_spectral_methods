function [DT,H10] = DT_H10_mat(d,N2,val)
DT = zeros(d*(N2+1),d*(N2+2));
H10 = zeros(d,d*(N2+2));
Id = eye(d);
if val == 1
    Id=intval(Id);
    DT=intval(DT);
    H10=intval(H10);
end
H10(:,1:d) = Id;
H10(:,1+d:d*2) = -Id/4;
for k=2:N2+1
    DT(1+(k-1)*d : k*d, 1+ (k-2)*d: (k-1)*d) = Id/(4*(k-1));
    DT(1+(k-1)*d : k*d, 1+ k*d : (k+1)*d) = -Id/(4*(k-1));
    H10(:, 1+k*d : (k+1)*d) = -((-1)^k)*Id/(k^2-1);
end
end