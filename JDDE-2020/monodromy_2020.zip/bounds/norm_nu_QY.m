function fval = norm_nu_QY(Q,nu,d,N2,Y,matnorm,val)
N1 = size(Y)*[1;0]/d;
vsums = zeros(N1+1,1);
T = zeros(d*(N2+1),d*(N2+2));
D = zeros(d*(N2+1));
Id = eye(d);
if val == 1
    Id = intval(Id);
    Y = intval(Y);
end
for j=2:N2+1
    T(1+(j-1)*d:j*d,1+(j-2)*d:(j-1)*d) = eye(d);
    T(1+(j-1)*d:j*d,1+j*d:(j+1)*d) = -eye(d);
    if val == 1
        D(1+(j-1)*d:j*d,1+(j-1)*d:j*d) = (1/intval(2*j))*Id;
    else
        D(1+(j-1)*d:j*d,1+(j-1)*d:j*d) = (1/(2*j))*Id;
    end
end
if val == 1
    vsums = intval(vsums);
    nu = intval(nu);
    T = intval(T);
end
nupow = nu.^(0:N2).';
nupow_inv = nu.^(-(N2+1:N2+N1+1)).';
Ys = symmetrize(Y);
H10 = zeros(2,d*(N2+2));
H10(:,1:d) = Id;
H10(:,d+1:2*d) = -Id/4;
for j=3:N2+2
    if val ==1 
        H10(1:d,1+d*(j-1):d*j) = -Id*(-1)^(j-1)/(intval(j-1)^2-1);
    else
        H10(1:d,1+d*(j-1):d*j) = -Id*(-1)^(j-1)/((j-1)^2-1);
    end
end
for k=1:N1+1
    Yk_short = Zmatrix(k,d,N1,N2)*Ys;
    colk_nonzeromode = Q*D*T*Yk_short;
    colk_zeromode = Q(:,1:d)*H10*Yk_short;
    colk = colk_zeromode + colk_nonzeromode;
    vsums(k)=sum(blocknorm(colk,d,matnorm).*nupow);
end

fval = max(nupow_inv.*vsums);
end