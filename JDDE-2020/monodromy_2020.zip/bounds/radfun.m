function radfun = radfun(input,lambda,arg_lambda,r,omega,M,d,nu,val,q)
if val.validate == 1
    nu = intval(nu);
end
if strcmp(val.type,'Morse')
    theta = input;
    if nargin < 10
        radfun = norm_nu_1copy(nu,inv(M-r*exp(1i*theta)*eye(length(M))),d,inf,'op_headbody',val.validate);
    else
        radfun = norm_nu_gen_op(nu,inv(M-r*exp(1i*theta)*eye(length(M))),q,d,inf,'op_headbody',val.validate);
    end
elseif strcmp(val.type,'ball')
    theta = input;
    if nargin < 10
        radfun = norm_nu_1copy(nu,inv(M-(lambda + r*exp(1i*theta))*eye(length(M))),d,inf,'op_headbody',val.validate);
    else
        radfun = norm_nu_gen_op(nu,inv(M-(lambda + r*exp(1i*theta))*eye(length(M))),q,d,inf,'op_headbody',val.validate);
    end
elseif strcmp(val.type,'sector')
    t = input;
    if nargin < 10
        radfun = [     
            norm_nu_1copy(nu,inv(M-(abs(lambda)-r)*exp(1i*(arg_lambda + omega*(1-2*t)))*eye(length(M))),d,inf,'op_headbody',val.validate);
            norm_nu_1copy(nu,inv(M-(abs(lambda)+(2*t-1)*r)*exp(1i*(arg_lambda - omega))*eye(length(M))),d,inf,'op_headbody',val.validate);
            norm_nu_1copy(nu,inv(M-(abs(lambda)+r)*exp(1i*(arg_lambda + omega*(2*t-1)))*eye(length(M))),d,inf,'op_headbody',val.validate);
            norm_nu_1copy(nu,inv(M-(abs(lambda)+(1-2*t)*r)*exp(1i*(arg_lambda + omega))*eye(length(M))),d,inf,'op_headbody',val.validate)
            ];
    else
        radfun = [     
            norm_nu_gen_op(nu,inv(M-(abs(lambda)-r)*exp(1i*(arg_lambda + omega*(1-2*t)))*eye(length(M))),q,d,inf,'op_headbody',val.validate);
            norm_nu_gen_op(nu,inv(M-(abs(lambda)+(2*t-1)*r)*exp(1i*(arg_lambda - omega))*eye(length(M))),q,d,inf,'op_headbody',val.validate);
            norm_nu_gen_op(nu,inv(M-(abs(lambda)+r)*exp(1i*(arg_lambda + omega*(2*t-1)))*eye(length(M))),q,d,inf,'op_headbody',val.validate);
            norm_nu_gen_op(nu,inv(M-(abs(lambda)+(1-2*t)*r)*exp(1i*(arg_lambda + omega))*eye(length(M))),q,d,inf,'op_headbody',val.validate)
            ];
    end
end

end