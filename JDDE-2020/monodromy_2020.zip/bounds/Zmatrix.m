function Z = Zmatrix(k,d,N1,N2)
Z = zeros(d*(N2+2),d*(2*N1+1));
if N1-k>=0
    iter = 0;
    while N1-k-iter>=0
        col_idx = N1-k-iter;
        row_idx = N2+1-iter; 
        Z(1+d*row_idx:d*(row_idx+1), 1+d*col_idx:d*(col_idx+1)) = eye(d);
        iter = iter + 1;
    end
end
end