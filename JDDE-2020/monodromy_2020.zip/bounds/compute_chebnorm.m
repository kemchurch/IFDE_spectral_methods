function chebnorm = compute_chebnorm(nu,input,dimension,matnorm,type,val)
% chebnorm = compute_chebnorm(nu,input,dimension,matnorm,type,val):
% compute the the ell_nu^1 (type=='ell_nu_1') or induced omega (type=='omega')
% norm for an input matrix (input) of matrix Chebyshev series coefficients
% of dimension (d) dxd, relative to the prescribed matrix norm (matnorm). The 
% input 'val' is a validation flag; if val==1 then nu will be intval'd.
% Finally, it implements the summation part of the computation of 
% \mathcal{T} from Lemma 5.1.1 type=='T_script'
d = dimension;
X = input;
if val == 1
    nu = intval(nu);
end
N = size(X)*[1;0]/d;
if strcmp(type,'ell_nu_1')==1
    nupow = (nu.^(0:N-1)).';
    chebnorm = sum(blocknorm(X,d,matnorm,val).*nupow);
elseif strcmp(type,'omega')==1
    nupow = (nu.^(0:N-1)).';
    omegapow = nupow.*[1;2*ones(N-1,1)];
    chebnorm = sum(blocknorm(X,d,matnorm,val).*omegapow);
elseif strcmp(type,'T_script')
    nupow = (nu.^(0:N-1)).';
    chebnorm = max(blocknorm(X,d,matnorm,val)./nupow);
end

end