function fval = norm_nu_1copy(nu,input,dimension,matnorm,type,val)
d = dimension;
X = input;
N = size(X)*[1;0]/d;

if strcmp(type,'op_body')==1
    if val == 1
        Y = intval(zeros(N,N));
    else
        Y = zeros(N,N);
    end
    for i=1:N
        for j=1:N
            Y(i,j)=norm(X(1+(i-1)*d:i*d,1+(j-1)*d:j*d),matnorm);
        end
        Y(i,:)=Y(i,:)*nu^(i-1);
    end
    colsum = sum(Y);
    for k = 1:N
        colsum(k)=colsum(k)/nu^(k-1);
    end
    fval = max(colsum);
elseif strcmp(type,'op_head_ell_nu_1')==1
    m = size(X)*[0;1]/d;
    if val == 1
        Y = intval(zeros(m));
    else
        Y = zeros(m);
    end
    for k=1:m
        Y(k) = norm(X(1:d,1+d*(k-1) : d*k),matnorm)/nu^(k-1);
    end
    fval = max(Y);
elseif strcmp(type,'op_headbody')==1
    X_nullrow = X(1:d,:);
    if val == 1
        Y_nullrow = intval(zeros(N,1));
    else
        Y_nullrow = zeros(N,1);
    end
    Y_nullrow(1) = norm(X_nullrow(1:d,1:d),matnorm);
    for i=2:N
        Y_nullrow(i) = nu^(-(i-2))*norm(X_nullrow(:,1+(i-1)*d:i*d),matnorm);
    end
    X_nullcolumn = X(d+1:end,1:d);
    if val == 1
        Y_nullcolumn = intval(zeros(N-1,1));
    else
        Y_nullcolumn = zeros(N-1,1);
    end
    for i=1:N-1
        Y_nullcolumn(i) = nu^(i-1)*norm(X_nullcolumn(1+(i-1)*d:i*d),matnorm);
    end
    X_remainder = X(d+1:end,d+1:end);
    if val == 1
        Y_remainder = intval(zeros(N-1,N-1));
    else
        Y_remainder = zeros(N-1,N-1);
    end
    for i=1:N-1
       for j=1:N-1
           Y_remainder(i,j) = norm(X_remainder(1+(i-1)*d:i*d,1+(j-1)*d:j*d),matnorm);
       end
        Y_remainder(i,:) = Y_remainder(i,:)*nu^(i-1);
    end
    
    colsum_nullrow = sum(Y_nullrow);
    sum_nullcolumn = sum(Y_nullcolumn);
    colsum_remainder = sum(Y_remainder);
    for k=1:N-1
        colsum_remainder(k) = colsum_remainder(k)/nu^(k-1);
    end
    fval = max(colsum_nullrow,sum_nullcolumn + max(colsum_remainder));
    
elseif strcmp(type,'chebmat')==1
%    Y = intval(zeros(N,1));
    fval = 0;
    for i=1:N
%        Y(i)=nu^(i-1)*norm(X(1+(i-1)*d:i*d,:),matnorm);
        fval = fval + nu^(i-1)*norm(X(1+(i-1)*d:i*d,:),matnorm);
    end
%    fval = sum(Y);
    
elseif strcmp(type,'chebmat_omega')==1
%    Y = intval(zeros(N,1));
%    Y(1) = norm(X(1:d,:),matnorm);
    fval = norm(X(1:d,:),matnorm);
    for i=2:N
%        Y(i)=2*nu^(i-1)*norm(X(1+(i-1)*d:i*d,:),matnorm);
        fval = fval + 2*nu^(i-1)*norm(X(1+(i-1)*d:i*d,:),matnorm);
    end
%    fval = sum(Y);
end
    
        

end

