function K2 = compute_K2(C1Qinv,DT,A_omega,S,d,nu,matnorm,val)
N2 = size(C1Qinv)*[1;0]/d - 1;
N1 = (size(S)*[1;0]/d-1)/2;
nupow_external = nu.^(N2+1:N2+1+N1);
m = zeros(N2+1,N1+1);
m_max = zeros(N2+1,1);
if val == 1
    m = intval(m);
    m_max = intval(m_max);
    weight = A_omega/((intval(N2)-intval(N1)+1)^2-1);
else
    weight = A_omega/((N2-N1+1)^2-1);
end
C1Qinv_times_DT = C1Qinv*DT;

for j=0:N2
    for k=0:N1
        if odd(j)==0
            m(j+1,k+1) = weight*norm(C1Qinv(1+d*j:(j+1)*d,1:d),matnorm) + norm(C1Qinv_times_DT(1+d*j:(j+1)*d,:)*Zmatrix(k,d,N1,N2)*S,matnorm);
        end
    end
    m(k+1,:) = m(k+1,:)./nupow_external;
    m_max(k+1) = max(m(k+1,:));
end
weights = zeros(N2,1);
for r = 1:N2
    if mod(r,2)==0
        weights(r) = 2/(r^2-1);
    end
end
K2 = m_max(1) + sum(m_max(2:end).*weights);

end