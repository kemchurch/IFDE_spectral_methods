function conv = chebmat_convolution(A,B,d)
% Computes the convolution of two Chebyshev matrix sequences A and B each
% being a block row of (dxd) matrix coefficients.
NA = rows(A)/d;
NB = rows(B)/d;
N = max(NA,NB);
conv = zeros(d*(NA+NB+1),d);
for k=0:NA+NB
    for j = -N:N
        if and( abs(j)+1<=NA , abs(k-j)+1<=NB)
            conv(1+k*d:(k+1)*d, :) = conv(1+k*d:(k+1)*d, :) +...
                A(1+abs(j)*d:(abs(j)+1)*d,:)*B(1+abs(k-j)*d:(abs(k-j)+1)*d,:);
        end
    end
end
end