function H = H1_matrix(N2,dimension)
d = dimension;
H = zeros(d*(N2+1),d*(N2+1));
I = eye(d);

%First row:
H(1:d,1:d)=I/2;
H(1:d,d+1:2*d)=-I/4;
for k=2:N2
    H(1:d,1+k*d:(k+1)*d)=-((-1)^k/(k^2-1))*I;
end

%Tridiagonal part
for k=1:N2
    H(1+d*k:(k+1)*d,1+d*(k-1):k*d) = (1/4*k)*I;
end
for k=1:N2-1
    H(1+d*k:(k+1)*d,1+d*(k+1):(k+2)*d) = (1/4*k)*I;
end

end