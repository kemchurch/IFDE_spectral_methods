function conv = cheb_matrix_convolution(A,B,d,val)
% Computes the convolution of a Chebyshev matrix sequence A with a square 
% matrix B. 
NA = rows(A)/d;
NB = columns(B)/d;
N = max(NA,NB);
conv = zeros(d*(NA+NB-1),d*(NB));
if val == 1
    conv = intval(conv);
end
for k=0:NA+NB-2
    for j = -N:N
        if and( abs(j)+1<=NA , abs(k-j)+1<=NB)
            conv(1+k*d:(k+1)*d, :) = conv(1+k*d:(k+1)*d, :) +...
                A(1+abs(j)*d:(abs(j)+1)*d,:)*B(1+abs(k-j)*d:(abs(k-j)+1)*d,:);
        end
    end
end
end