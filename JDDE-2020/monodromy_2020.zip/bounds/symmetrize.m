function Ys = symmetrize(Y,val)
if rows(Y)==columns(Y)
    Ys = Y;
else
    d = columns(Y);
    N = rows(Y)/d;
    Ys = zeros(2*rows(Y)-d,d);
    if val == 1
        Ys = intval(Ys);
    end
    for j=1:N-1
        Ys(end-(j)*d+1:end-(j-1)*d,:) = Y(end-(j)*d+1:end-(j-1)*d,:);
        Ys(1+(j-1)*d:j*d,:) = Y(end-(j)*d+1:end-(j-1)*d,:);
    end
    Ys(1+(N-1)*d:(N)*d,:) = Y(end-(N)*d+1:end-(N-1)*d,:);
end

end