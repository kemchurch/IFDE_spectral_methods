function [m,curve] = getmesh(intervals,M,dim,nu,val,q,finecomp,type,pow)
if nargin == 8
    pow = 1;
end
m = zeros(intervals+1,1);
m(1) = 0;
meshval = val;
meshval.mesh = finecomp;
meshval.validate = 0;
meshval.plot = 0;
breakflag = [];
if strcmp(type,'explicit')==1
    if q == 1
        [~,mesh,curve,breakflag] = bound_pq1_c1(mid(M),dim,mid(nu),meshval);
    else
        [~,mesh,curve,breakflag] = bound_1pLq_c1(mid(M),dim,mid(nu),meshval,q);
    end
elseif strcmp(type,'proxy')==1
    if strcmp(val.type,'Morse')==1
        mesh = linspace(0,pi,finecomp);
        e = eig(mid(M));
        curve = 1./min(abs(e-mid(val.Morse_radius).*exp(1i*mesh))).^pow;
    elseif strcmp(val.type,'sector')==1
        mesh = linspace(0,1,finecomp);
        e = eig(mid(M));
        s = sector(mesh,mid(val.lambda),mid(val.sector_radius),mid(val.omega),'zero_one');
        curve = [ 1./min(abs(e - s(1,:))).^pow ; 1./min(abs(e - s(2,:))).^pow...
            ; 1./min(abs(e - s(3,:))).^pow ; 1./min(abs(e - s(4,:))).^pow ];
        curve = max(curve);
    end
end
if breakflag==0
    disp('Failed to compute the mesh due to singularity. Increase the number of intervals.');
    return
elseif breakflag==1
    disp('Failed to compute the mesh because c1c2c3>=1 is guaranteed. Increase the number of intervals and/or fineness (finecomp) and/or N2 and/or change nu.');
    return
end
meshint = zeros(finecomp,1);
meshint(1) = trapz(mesh(1:2),curve(1:2));
for k=2:finecomp-1
    meshint(k) = trapz(mesh(k:k+1),curve(k:k+1));
end
bucket_weight = sum(meshint)/intervals;
currentpoint = 1;
bucket = meshint(currentpoint);
for k=2:intervals + 1
    while bucket < bucket_weight
        if currentpoint > finecomp-1
            break
        else
            currentpoint = currentpoint + 1;
            bucket = bucket + meshint(currentpoint);
        end
    end
    if k < intervals
        if currentpoint>1
            m(k) = mesh(currentpoint);
        else
            disp('Error with mesh generation. Increase fineness (finecomp) parameter.')
            break
        end
    else
        m(k) = mesh(currentpoint);
    end
    bucket = 0;
end