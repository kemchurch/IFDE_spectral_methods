function G = boldG_func(dim,DT,N1,N2,Y,L,val)
zeta = blkdiag(zeros(dim*(N2+1),dim*(N2+1)),eye(dim*(N1+1)));
G = zeta*DT(1:dim*(N1+N2+2), 1:dim*(N1+N2+1))*cheb_matrix_convolution(Y,L,dim,val);
end