function [c1,mesh,curve,breakflag] = bound_1pLq_c1(M,d,nu,val,q)
breakflag = [];
curve = [];
if val.validate == 1
    nu = intval(nu);
end
R=0;
mesh = [];
if strcmp(val.type,'sector')
    lambda = intval(val.lambda);
    arg_lambda = -1i*log(lambda/abs(lambda));
    radius = intval(val.sector_radius);
    omega = intval(val.omega);
    if isa(val.mesh,'double')
        if val.plot==1
            gcf;
            drawnow;
            hold on
        end
        if length(val.mesh)>1
            kf = length(val.mesh)-1;
        else
            kf = val.mesh;
        end
        for k=1:kf
            if length(val.mesh)>1
                t=infsup(val.mesh(k),val.mesh(k+1));
            else
                t = infsup((k-1)/val.mesh,k/val.mesh);
            end
            if val.validate == 0
                lambda = mid(lambda);
                arg_lambda = mid(arg_lambda);
                radius = mid(radius);
                omega = mid(omega);
                t = sup(t);
                nu = mid(nu);
            end
            nxt_full = radfun(t,lambda,arg_lambda,radius,omega,M,d,nu,val);
            nxt = max(nxt_full);
            if sum(isnan(nxt_full))>0
                disp('Error: (M-zI)^{-1} has a singularity to intval precision with the prescribed validation structure.');
                disp('Failure on the interval');
                disp(t)
                breakflag=0;
                break
            elseif sup(nxt)*val.c2c3>=1
                disp('Error: With this level of mesh refinement and/or N2 and nu, we can not prove c1c2c3<1.');
                disp('Failure on the interval');
                disp(t);
                breakflag=1;
                break
            else
                if val.plot==1
                    S = sector(linspace(inf(t),min(sup(t),1),10),mid(lambda),mid(radius),mid(omega),'zero_one');
                    plot(S(1,:),'black')
                    plot(S(2,:),'black')
                    plot(S(3,:),'black')
                    plot(S(4,:),'black')
                    axis equal;
                end
            end
            mesh = [mesh;t];
            curve = [curve;nxt];
            R = max(R,nxt);
        end
        if sum(isnan(nxt_full))>0
            c1 = NaN;
        elseif sup(nxt)*val.c2c3>=1
            c1 = nxt;
        else
            c1 = max(R,1/(abs(lambda)-radius));
        end
    elseif val.mesh == 'reactive'
        h = val.initial_stepsize;
        safe = 1+val.reactive_target;
        t = intval(0);
        curve = [];
        mesh = [];
        if isempty(val.plot)==0
            if val.plot==1
            gcf;
            drawnow;
            hold on
            end
        end
        while sup(t)<1
            t_next = infsup(sup(t),min(sup(t)+h,1));
            nxt = max(radfun(t_next,lambda,arg_lambda,radius,omega,M,d,nu,val,q));
            if sup(nxt)<1/val.c2c3
                R = max(R,nxt);
                t = t_next;
                mesh = [mesh;t];
                if isempty(val.plot)==0
                    if val.plot==1
                        S = sector(linspace(inf(t),min(sup(t),1),10),mid(lambda),mid(radius),mid(omega),'zero_one');
                        plot(S(1,:),'black')
                        plot(S(2,:),'black')
                        plot(S(3,:),'black')
                        plot(S(4,:),'black')
                        axis equal;
                    end
                end
                % -- Reactive stepsize adjustment
                h = min(val.reactive_target/(val.c2c3*sup(nxt)/h),1-h);
                % --
                curve = [curve;nxt];
            else
                if h>val.min_stepsize
                    %h = max(0.5*h, val.min_stepsize);
                    h = max(val.reactive_target/(val.c2c3*sup(nxt)/h), val.min_stepsize);
                else
                    disp('Minimum step size reached; reactive mesh failed for given validation structure.')
                    disp(['Last computed norm bound: ',num2str(sup(nxt))]);
                    c1 = NaN;
                    return
                end
            end
        end
        c1 = max(R,1/radius);
    end
        
    
elseif strcmp(val.type,'Morse')
    radius = intval(val.Morse_radius);
    if isa(val.mesh,'double')
        if val.plot==1
            gcf;
            drawnow;
            hold on
        end
        for k=1:max(length(val.mesh)-1,val.mesh(1))
            if length(val.mesh)>1
                theta=infsup(val.mesh(k),val.mesh(k+1));
            else
                theta = infsup((k-1)*pi/val.mesh,k*pi/val.mesh);
            end
            if val.validate == 0
                radius = mid(radius);
                theta = sup(theta);
            end
            nxt = radfun(theta,[],[],radius,[],M,d,nu,val,q);
            if sum(isnan(nxt))>0
                disp('Error: (M-zI)^{-1} has a singularity to intval precision with the prescribed validation structure.');
                disp('Failure on the interval');
                disp(theta)
                breakflag=0;
                break
            elseif sup(nxt)*val.c2c3>=1
                disp('Error: With this level of mesh refinement and/or N2 and nu, we can not prove c1c2c3<1.')
                disp('Failure on the interval');
                disp(theta);
                breakflag=1;
                break
            else
                if val.plot==1
                % -- Plot the validated circle; acts as progress bar
                plot(mid(radius)*exp(1i*linspace(inf(theta),sup(theta),10)),'black');
                plot(mid(radius)*exp(1i*linspace(-sup(theta),-inf(theta),10)),'black');
                axis([-1 1 -1 1]);
                drawnow;
                % --
                end
            end
            curve = [curve;nxt];
            mesh = [mesh;theta];
            R = max(R,nxt);
        end
        if isnan(nxt)==1
            c1 = NaN;
        elseif sup(nxt)*val.c2c3>=1
            c1 = nxt;
        else
            c1 = max(R,1/radius);
        end
    elseif val.mesh == 'reactive'
        h = val.initial_stepsize;
        trail = repmat(val.reactive_target,3,1);
        theta = intval(0);
        curve = [];
        mesh = [];
        if isempty(val.plot)==0
            if val.plot==1
            gcf;
            drawnow;
            hold on
            end
        end
        while sup(theta)<pi
            theta_next = infsup(sup(theta),min(sup(theta)+h*pi,pi));
            nxt = radfun(theta_next,[],[],radius,[],M,d,nu,val,q);
            if sum(isnan(nxt))>0
                if h>val.min_stepsize
                    %h = max(0.5*h, val.min_stepsize);
                    h = max(min(mean(trail),val.reactive_target)/(val.c2c3*sup(nxt)/h), val.min_stepsize);
                else
                    disp('Minimum step size reached; reactive mesh failed for given validation structure.')
                    disp(['Last computed norm bound:',num2str(sup(nxt))]);
                    c1 = NaN;
                    return
                end
            elseif sup(nxt)<1/val.c2c3
                R = max(R,nxt);
                theta = theta_next;
                mesh = [mesh;theta];
                trail = [sup(nxt)*val.c2c3;trail(1:end-1)];
                if isempty(val.plot)==0
                    if val.plot==1
                    % -- Plot the validated circle; acts as progress bar
                    plot(mid(radius)*exp(1i*linspace(inf(theta),sup(theta),10)),'black');
                    plot(mid(radius)*exp(1i*linspace(-sup(theta),-inf(theta),10)),'black');
                    axis([-1 1 -1 1]);
                    drawnow;
                    % --
                    end
                end
                % -- Reactive stepsize adjustment
                h = min(min(mean(trail),val.reactive_target)/(val.c2c3*sup(nxt)/h),1-sup(theta_next)/pi);
                % --
                curve = [curve;nxt];
            else
                if h>val.min_stepsize
                    %h = max(0.5*h, val.min_stepsize);
                    h = max(min(mean(trail),val.reactive_target)/(val.c2c3*sup(nxt)/h), val.min_stepsize);
                else
                    disp('Minimum step size reached; reactive mesh failed for given validation structure.')
                    disp(['Last computed norm bound:',num2str(sup(nxt))]);
                    c1 = NaN;
                    return
                end
            end
        end
        c1 = max(R,1/radius);
    end
    
elseif strcmp(val.type,'ball')
    lambda = intval(val.lambda);
    arg_lambda = -1i*log(lambda/abs(lambda));
    radius = intval(val.ball_radius);
    for k=1:max(length(val.mesh)-1,val.mesh(1))
        if length(val.mesh)>1
            theta=infsup(val.mesh(k),val.mesh(k+1));
        else
            theta = infsup((k-1)*2*pi/val.mesh,k*2*pi/val.mesh);
        end
        if val.validate == 0
            lambda = mid(lambda);
            arg_lambda = mid(arg_lambda);
            radius = mid(radius);
            theta = sup(theta);
        end
        nxt = radfun(theta,lambda,arg_lambda,radius,[],M,d,nu,val,q);
        if isnan(nxt)==1
            disp('Error: (M-zI)^{-1} has a singularity to intval precision with the prescribed validation structure.');
            disp('Failure on the interval');
            disp(theta)
            break
        end
        curve = [curve;nxt];
        R = max(R,nxt);
    end
    if isnan(nxt)==1
        c1 = NaN;
    else
        c1 = max(R,1/radius);
    end
end

end