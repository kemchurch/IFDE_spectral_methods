function J = compute_J(DT,H10,S,N2,d,nu,matnorm)
N1 = (size(S)*[1;0]/d-1)/2;
nupow_internal = (nu.^(0:N2)).';
nupow_external = nu.^(N2+1:N2+1+N1);
H10_repr = DT + [H10;zeros(d*(N2),d*(N2+2))];
J_vect = zeros(1,N1+1);
for k=0:N1
    rowk = H10_repr(1+k*d:(k+1)*d, :);
    vect = blocknorm(rowk*Zmatrix(k,d,N1,N2)*S, d, matnorm).*nupow_internal;
    J_vect(k+1) = sum(vect)/nupow_external(k+1);
end
J = max(J_vect);
end