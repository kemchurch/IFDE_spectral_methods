function fval = g_func(nu)
fval = 2 + (1/nu - nu)*atanh(1/nu);
end