Dear reviewer,

First, thank you for agreeing to review this paper. Your service is greatly appreciated.
The examples from Section 8/9 can be found in the "Examples" folder. To run them, make sure
to add all folders contained in this archive to your MATLAB path. You will also need a valid
INTLAB license to run all examples except for spurious_flowers.m. Each file in the examples
folder is commented with the name of the theorem it proves and any instructions you might
need. These examples can also serve as a guide to the syntax for the main components of the
code package, which include:

- M_truncation (floating point monodromy operator discretization)
- M_truncation_int (interval arithmetic monodromy operator discretization, requires INTLAB)
- bound_pq1_c2c3 (c2 and c3 bounds for the case p=q=1)
- bound_pq1_c1 (c1 bound for the case p=q=1)
- bound_1pLq_c2c3 (c2 and c3 bounds for the case 1=p<q)
- bound_1pLq_c1 (c1 bound for the case 1=p<q)

Before publication I will add helpfile comments to each of these so that others can know how
to use them without figuring it out by example. Finally, you needed a password to access this
zip archive; this will of course be removed at publication and a proper readme will be added (
with a BSD license, most likely a two-clause).

Thank you for your valuable time. I hope you find the paper interesting.

Sincerely,
Kevin Church