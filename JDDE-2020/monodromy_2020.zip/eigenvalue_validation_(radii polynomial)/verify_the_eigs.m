function [Eigs,rad_pol]=verify_the_eigs(iA,m,tol)

%%% JP: This code takes an interval matrix (possibly of radius 0), computes 
%%% its eigendecomposition using the "eig" function in MATLAB, and then
%%% validates the existence of each eigenpair (v,lambda) of the nonlinear
%%% problem iA*v-lambda*v=0. It does so using the radii polynomials. If
%%% successful, the code returns the list of eigenvalues Eigs together
%%% with the radius enclosing them. Hence, the interval
%%% [Eigs(k)-rad_pol,Eigs(k)+rad_pol] constains a unique eigenvalue

%%% K: Added nonstantdard tolerance parameter. Eigenvalues that are smaller
%%% than tol will be ignored. The count of these eigenvalues should be m.
%%% If it isn't there will be an error. This can be useful to tune for
%%% some problems, where the structure guarantees a finite (known) number 
%%% of eigenvalues that are precisely zero. You might also only be
%%% interested in validating specific eigenvalues, and this can help with
%%% that. On the other hand, you might just have very small eigenvalues and
%%% need to accomodate for all of them in proofs (and should take tol=0).

A = mid(iA);

[V,D] = eig(A);
Eigs = diag(D); 

index = find(abs(Eigs)>=tol);

Eigs = Eigs(index);
V = V(:,index);
n = length(index);

rad_pol = zeros(1,n);

if n + m ~= length(A)
    disp('Problem with count of zero eigenvalues.')
    return
end

for j = 1:n
    rad_pol(j)=enc_eig(iA,V(:,j),Eigs(j));
end

end