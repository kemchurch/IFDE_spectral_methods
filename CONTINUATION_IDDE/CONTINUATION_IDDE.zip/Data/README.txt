This folder is empty until the function main.m attempts/completes a proof. 
The folder is necessary for the function to work, and should not be 
deleted.